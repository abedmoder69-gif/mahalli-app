# Mahalli: no custom ProGuard rules required for v1.
